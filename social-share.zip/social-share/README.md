# CMS-plugin
3rd cms assinment
Social share Plugin
=====================

<!--
Plugin Name: Social share
Version: 1.1.6
Domain Path: /languages
Author: Tarun Bhargav
License: GPL2 or later
-->

Description

This plugin helps you to create social media buttons at start of the post or at end of the as well as at start of the page and at end of the page. You also have the option to create a footer at 4 different positions that is left centre, right centre, bottom right and bottom left. You can also change the positions of social media icons and have them displayed in the order you want.

Installation

1.  Download the plugin file from the learn JCUB submission. 
2.  Go to add new plugin in WordPress dashboard and select upload plugin. After that select the plugin zip file and upload the file. then click install.
3.  Once the plugin is installed activate the plugin.

Once Activated

1.  You can see social share plugin in the dashboard. click on it and copy the short-code given. 
2.  Paste the short-code in a post or on a page where ever you want your social media icon’s to display. Then update the page. 
3.  After updating go back to the social share plugin and select where you want your icons to display, like on top of the page or bottom of the page. you can also select the floating side bar in general settings.
4.  After that click on social media and select the social media you want to display. you can also change the order by which you wanna display the icons. Then click on save the changes button.
5. Now go to the page or post where you pasted the short code and reload the page. you will be able to see the social media icons. when you click on them they will redirect you to the relevant social media site.

Refrences:
TableDnD plug-in for JQuery.
http://docs.jquery.com/License.

https://www.youtube.com/watch?v=OfLvQ8KtW2g

https://www.youtube.com/watch?v=pbekOEr0Wo0

https://www.youtube.com/watch?v=I6IY2TqnPDA
