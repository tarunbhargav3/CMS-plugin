<div class="save-wrapper" style="position:relative">
	<input id="smb-save-btn" type="submit" value="<?php echo esc_attr__('Save Settings', 'smb');?>"/>

				<svg id="loadSpinner" width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid" style="height: 45px;display: inline-block;width: 45px;position: absolute; left: 230px; top:20px; display:none;"><circle cx="50" cy="50" fill="none" stroke="#6448e7" stroke-width="10" r="35" stroke-dasharray="164.93361431346415 56.97787143782138" transform="rotate(251.563 50 50)"><animateTransform attributeName="transform" type="rotate" calcMode="linear" values="0 50 50;360 50 50" keyTimes="0;1" dur="2s" begin="0s" repeatCount="indefinite"></animateTransform></circle></svg>

	<div id="smb-save-msg" style="display:none;"></div>
</div>
